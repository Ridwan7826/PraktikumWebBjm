@extends('layouts.master')

@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Barang Masuk</h6>
        </div>
        <div class="card-body">
            <form action="/admin/masuk/simpan" method="POST">
                @csrf
                <div class="form-group">
                    <label>Pilih Barang</label>
                    <select name="barang_id" class="form-control" required>
                        <option value="">-- Cari Barang --</option>
                        @foreach($barang as $item)
                            <option value="{{ $item->id }}">{{ $item->kode }} - {{ $item->nama }} (Stok: {{ $item->stok }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah Masuk</label>
                    <input type="number" name="jumlah" class="form-control" required min="1">
                </div>
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" value="{{ date('Y-m-d') }}" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Stok Masuk</button>
            </form>
        </div>
    </div>
</div>
@endsection