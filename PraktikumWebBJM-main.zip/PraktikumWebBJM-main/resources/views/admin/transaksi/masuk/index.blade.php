@extends('layouts.master')

@section('content')
<div class="row">
    <div class="col-md-6">
        <h1 class="h3 mb-4 text-gray-800">Riwayat Barang Masuk</h1>
    </div>
    <div class="col-md-6 text-right">
        {{-- Tombol untuk ke halaman form tambah --}}
        <a href="/admin/masuk/tambah" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-plus"></i>
            </span>
            <span class="text">Tambah Stok Masuk</span>
        </a>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Menampilkan Data Barang Masuk</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Barang</th>
                        <th>Jumlah Masuk</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $key => $item)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $item->tanggal }}</td>
                        <td>
                            {{-- Mengambil nama barang dari relasi --}}
                            {{ $item->barang->nama ?? 'Barang Terhapus' }} 
                            <small class="text-muted">({{ $item->barang->kode ?? '-' }})</small>
                        </td>
                        <td>
                            <span class="badge badge-success">+ {{ $item->jumlah }}</span>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {{ $data->links() }}
        </div>
    </div>
</div>
@endsection