@extends('layouts.master')

@section('content')
<div class="row">
    <div class="col-md-6">
        <h1 class="h3 mb-4 text-gray-800">Riwayat Barang Keluar</h1>
    </div>
    <div class="col-md-6 text-right">
        <a href="/admin/keluar/tambah" class="btn btn-danger btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-minus"></i>
            </span>
            <span class="text">Input Barang Keluar</span>
        </a>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-danger">Menampilkan Data Barang Keluar</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Barang</th>
                        <th>Jumlah Keluar</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $key => $item)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $item->tanggal }}</td>
                        <td>
                            {{ $item->barang->nama ?? 'Barang Terhapus' }}
                            <small class="text-muted">({{ $item->barang->kode ?? '-' }})</small>
                        </td>
                        <td>
                            <span class="badge badge-danger">- {{ $item->jumlah }}</span>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {{ $data->links() }}
        </div>
    </div>
</div>
@endsection