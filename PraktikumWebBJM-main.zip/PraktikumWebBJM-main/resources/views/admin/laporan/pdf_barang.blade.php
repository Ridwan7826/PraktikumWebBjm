<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Data Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        
        /* Gaya Kop Surat */
        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid black;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            font-size: 20px; /* Lebih gede dikit biar gagah */
            font-weight: bold;
            text-transform: uppercase;
        }
        .header p {
            margin: 2px 0;
            font-size: 12px;
        }

        /* Gaya Tabel */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #e0e0e0; /* Abu muda biar jelas header tabelnya */
            text-align: center;
            font-weight: bold;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }

        /* Gaya Tanda Tangan */
        .ttd-container {
            width: 100%;
            margin-top: 40px;
        }
        .ttd-box {
            float: right;
            width: 250px;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>INVENTARIS COMPUTER JAYA</h1>
        <p>PUSAT PENJUALAN LAPTOP, SERVICE, & SPAREPART</p>
        <p>Jl. Kayutangi Ujung No. 99, Banjarmasin, Kalimantan Selatan</p>
        <p>Telp: (0511) 4455-6677 | Email: admin@computerjaya.com</p>
    </div>

    <h3 style="text-align: center; margin-bottom: 15px; text-decoration: underline;">LAPORAN STOK BARANG GUDANG</h3>
    
    <table class="table">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="15%">Kode Barang</th>
                <th>Nama Barang</th>
                <th width="15%">Stok Tersedia</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $key => $item)
            <tr>
                <td class="text-center">{{ $key + 1 }}</td>
                <td class="text-center">{{ $item->kode }}</td>
                <td>{{ $item->nama }}</td>
                <td class="text-center">{{ $item->stok }} Unit</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="ttd-container">
        <div class="ttd-box">
            <p>Banjarmasin, {{ date('d F Y') }}</p>
            <p>Mengetahui,</p>
            <br><br><br><br> <p style="text-decoration: underline; font-weight: bold;">{{ Auth::user()->name ?? 'Administrator' }}</p>
            <p>Kepala Gudang</p>
        </div>
    </div>

</body>
</html>