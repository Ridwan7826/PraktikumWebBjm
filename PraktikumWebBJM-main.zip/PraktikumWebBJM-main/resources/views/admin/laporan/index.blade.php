@extends('layouts.master')

@section('content')
<div class="container-fluid">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Pusat Laporan</h1>
    </div>

    <div class="row">
        
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Laporan Inventaris</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800 mb-2">Stok Barang</div>
                            <p class="text-sm text-gray-400">Cetak data seluruh barang beserta sisa stok saat ini.</p>
                            
                            <a href="/admin/laporan/barang" target="_blank" class="btn btn-primary btn-sm shadow-sm">
                                <i class="fas fa-print fa-sm text-white-50"></i> Cetak PDF
                            </a>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-boxes fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        </div>

</div>
@endsection