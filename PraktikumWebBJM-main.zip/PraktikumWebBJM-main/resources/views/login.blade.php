<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login System - Inventaris</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; }
        .animate-gradient { background-size: 200% 200%; animation: gradient-animation 8s ease infinite; }
        @keyframes gradient-animation { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .glass-card { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .input-glass { background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; transition: all 0.3s ease; }
        .input-glass:focus { background: rgba(255, 255, 255, 0.1); border-color: #3b82f6; box-shadow: 0 0 15px rgba(59, 130, 246, 0.3); }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4 overflow-hidden relative">
    
    <div class="absolute top-0 -left-20 w-96 h-96 bg-blue-600 rounded-full mix-blend-screen filter blur-[120px] opacity-20 animate-pulse"></div>
    <div class="absolute bottom-0 -right-20 w-96 h-96 bg-emerald-500 rounded-full mix-blend-screen filter blur-[120px] opacity-20 animate-pulse"></div>

    <div class="w-full max-w-5xl flex flex-col md:flex-row glass-card rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 z-10">
        
        <div class="hidden md:flex md:w-1/2 p-12 flex-col justify-between relative bg-slate-900/50">
            <div class="relative z-10">
                <div class="w-12 h-12 bg-gradient-to-tr from-blue-500 to-emerald-400 rounded-2xl mb-8 flex items-center justify-center shadow-lg shadow-blue-500/20">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <h1 class="text-4xl font-extrabold text-white leading-tight mb-4">
                    Sistem Inventaris <br> <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">Terintegrasi.</span>
                </h1>
                <p class="text-slate-400 text-lg">Kelola aset dengan tampilan modern dan performa maksimal.</p>
            </div>
            <div class="grid grid-cols-2 gap-4 relative z-10">
                <div class="p-4 rounded-3xl bg-white/5 border border-white/5">
                    <p class="text-blue-400 font-bold text-xl leading-none">v2.0</p>
                    <p class="text-slate-500 text-xs mt-1 uppercase tracking-wider font-semibold">Version</p>
                </div>
                <div class="p-4 rounded-3xl bg-white/5 border border-white/5">
                    <p class="text-emerald-400 font-bold text-xl leading-none">Secure</p>
                    <p class="text-slate-500 text-xs mt-1 uppercase tracking-wider font-semibold">Encryption</p>
                </div>
            </div>
        </div>

        <div class="w-full md:w-1/2 p-10 md:p-16 bg-slate-900/80 flex flex-col justify-center">
            <div class="mb-8">
                <h2 class="text-2xl font-bold text-white mb-2">Login Inventaris</h2>
                <p class="text-slate-400">Masukkan username Anda untuk melanjutkan.</p>
            </div>

            @if ($errors->any())
                <div class="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-400 text-sm">
                    <ul>@foreach ($errors->all() as $error) <li>• {{ $error }}</li> @endforeach</ul>
                </div>
            @endif

            <form action="{{ route('login') }}" method="POST" class="space-y-6">
                @csrf
                
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-2">Username</label>
                    <input type="text" name="username" required 
                        class="w-full px-5 py-4 rounded-2xl input-glass outline-none focus:ring-2 focus:ring-blue-500/50 placeholder-slate-500"
                        placeholder="Masukan username (ex: admin)">
                </div>

                <div>
                    <label class="text-sm font-medium text-slate-300 mb-2 block">Password</label>
                    <input type="password" name="password" required 
                        class="w-full px-5 py-4 rounded-2xl input-glass outline-none focus:ring-2 focus:ring-blue-500/50 placeholder-slate-500"
                        placeholder="••••••••••••">
                </div>

                <button type="submit" 
                    class="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-emerald-500 text-white font-bold text-lg shadow-xl shadow-blue-500/20 hover:shadow-blue-500/40 transition duration-300 transform hover:-translate-y-1 active:scale-95 animate-gradient">
                    Masuk Sekarang
                </button>
            </form>

            <div class="mt-8 pt-8 border-t border-white/5 text-center">
                <p class="text-slate-500 text-sm">&copy; {{ date('Y') }} Inventaris System</p>
            </div>
        </div>
    </div>
</body>
</html>