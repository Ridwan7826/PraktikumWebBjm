<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use App\Models\BarangMasuk;
use App\Models\BarangKeluar;

class TransaksiController extends Controller
{
    // ================= BARANG MASUK =================

    // 1. Tampilkan List Riwayat (Tabel)
    public function index_masuk()
    {
        // Ambil data barang masuk, urutkan dari yang terbaru
        $data = BarangMasuk::with('barang')->latest()->paginate(10);
        return view('admin.transaksi.masuk.index', compact('data'));
    }

    // 2. Tampilkan Form Tambah
    public function create_masuk()
    {
        $barang = Barang::all();
        return view('admin.transaksi.masuk.tambah', compact('barang'));
    }

    // 3. Proses Simpan
    public function store_masuk(Request $request)
    {
        // Simpan History
        BarangMasuk::create([
            'barang_id' => $request->barang_id,
            'jumlah'    => $request->jumlah,
            'tanggal'   => $request->tanggal,
        ]);

        // Update Stok Barang
        $barang = Barang::find($request->barang_id);
        $barang->stok += $request->jumlah;
        $barang->save();

        notify()->success('Stok Masuk Berhasil Ditambahkan! 🚀');
        return redirect('/admin/masuk'); // Balik ke halaman List
    }

    // ================= BARANG KELUAR =================

    public function index_keluar()
    {
        $data = BarangKeluar::with('barang')->latest()->paginate(10);
        return view('admin.transaksi.keluar.index', compact('data'));
    }

    public function create_keluar()
    {
        $barang = Barang::all();
        return view('admin.transaksi.keluar.tambah', compact('barang'));
    }

    public function store_keluar(Request $request)
    {
        $barang = Barang::find($request->barang_id);

        if ($barang->stok < $request->jumlah) {
            notify()->error('Stok gak cukup bro! Sisa: ' . $barang->stok);
            return redirect()->back();
        }

        BarangKeluar::create([
            'barang_id' => $request->barang_id,
            'jumlah'    => $request->jumlah,
            'tanggal'   => $request->tanggal,
        ]);

        $barang->stok -= $request->jumlah;
        $barang->save();

        notify()->success('Barang Keluar Berhasil Disimpan! 🔥');
        return redirect('/admin/keluar');
    }
}