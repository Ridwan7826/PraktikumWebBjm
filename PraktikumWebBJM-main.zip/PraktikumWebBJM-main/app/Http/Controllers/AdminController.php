<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;       // Model Barang
use App\Models\BarangMasuk;  // Tambahan: Model Barang Masuk
use App\Models\BarangKeluar; // Tambahan: Model Barang Keluar
use App\Models\User;         // Tambahan: Model User

class AdminController extends Controller
{
    // --- HALAMAN DASHBOARD (UPDATED) ---
    // Sekarang sudah menghitung data real-time dari database
    public function admin()
    {
        // 1. Hitung Total Stok (Sum kolom stok di tabel barang)
        $stok = Barang::sum('stok');

        // 2. Hitung Total Barang Masuk (Sum kolom jumlah)
        $masuk = BarangMasuk::sum('jumlah');

        // 3. Hitung Total Barang Keluar (Sum kolom jumlah)
        $keluar = BarangKeluar::sum('jumlah');

        // 4. Hitung Jumlah User/Admin
        $user = User::count();

        // Kirim variabel ke view beranda
        return view('admin.beranda', compact('stok', 'masuk', 'keluar', 'user'));
    }

    // --- CRUD BARANG (TETAP AMAN, TIDAK DIUBAH) ---

    // 1. Tampilkan Data
    public function barang()
    {
        $data = Barang::paginate(5);
        return view('admin.barang.index', compact('data'));
    }

    // 2. Form Tambah
    public function tambah_barang()
    {
        return view('admin.barang.tambah');
    }

    // 3. Simpan Barang Baru
    public function simpan_barang(Request $request)
    {
        Barang::create([
            'kode' => $request->kode,
            'nama' => $request->nama,
            'stok' => $request->stok,
        ]);

        // Notif Sukses
        notify()->success('Data Barang Berhasil Disimpan! 🎉');

        return redirect('/admin/barang');
    }

    // 4. Form Edit
    public function edit_barang($id)
    {
        $data = Barang::find($id);
        return view('admin.barang.edit', compact('data'));
    }

    // 5. Update Barang
    public function update_barang(Request $request, $id)
    {
        $barang = Barang::find($id);
        $barang->update([
            'kode' => $request->kode,
            'nama' => $request->nama,
            'stok' => $request->stok,
        ]);

        // Notif Sukses
        notify()->info('Data Barang Berhasil Diupdate! 😎');

        return redirect('/admin/barang');
    }

    // 6. Hapus Barang
    public function delete_barang($id)
    {
        $barang = Barang::find($id);
        $barang->delete();

        // Notif Sukses
        notify()->warning('Data Barang Berhasil Dihapus! 🗑️');

        return redirect('/admin/barang');
    }
}