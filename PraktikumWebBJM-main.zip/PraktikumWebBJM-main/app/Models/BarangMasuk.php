<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BarangMasuk extends Model
{
    use HasFactory;

    // --- TAMBAHKAN INI (DAFTAR KOLOM YANG BOLEH DIISI) ---
    protected $fillable = ['barang_id', 'jumlah', 'tanggal'];

    // Relasi ke barang (opsional tapi bagus)
    public function barang()
    {
        return $this->belongsTo(Barang::class);
    }
}