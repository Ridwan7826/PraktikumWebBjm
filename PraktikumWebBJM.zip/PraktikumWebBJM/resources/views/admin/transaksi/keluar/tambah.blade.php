@extends('layouts.master')

@section('content')
<div class="container-fluid">
    {{-- Tampilkan Error Jika Stok Kurang --}}
    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-danger">Form Barang Keluar</h6>
        </div>
        <div class="card-body">
            <form action="/admin/keluar/simpan" method="POST">
                @csrf
                <div class="form-group">
                    <label>Pilih Barang</label>
                    <select name="barang_id" class="form-control" required>
                        <option value="">-- Cari Barang --</option>
                        @foreach($barang as $item)
                            <option value="{{ $item->id }}">{{ $item->kode }} - {{ $item->nama }} (Stok: {{ $item->stok }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah Keluar</label>
                    <input type="number" name="jumlah" class="form-control" required min="1">
                </div>
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" value="{{ date('Y-m-d') }}" required>
                </div>
                <button type="submit" class="btn btn-danger">Simpan Stok Keluar</button>
            </form>
        </div>
    </div>
</div>
@endsection