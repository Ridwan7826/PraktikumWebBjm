<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Inventaris Dashboard</title>
    
    @notifyCss

    <link href="{{ asset('sbadmin/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <link href="{{ asset('sbadmin/css/sb-admin-2.min.css') }}" rel="stylesheet">

    <style>
        /* 1. SETUP GLOBAL & FONT */
        :root {
            --bg-dark: #0f172a;      /* Slate 900 (Background Login) */
            --bg-card: rgba(30, 41, 59, 0.7); /* Slate 800 + Transparan */
            --text-main: #f8fafc;    /* Slate 50 (Putih Terang) */
            --text-muted: #94a3b8;   /* Slate 400 (Abu-abu) */
            --border-glass: rgba(255, 255, 255, 0.1);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            background-color: var(--bg-dark) !important;
            color: var(--text-muted);
        }

        #wrapper #content-wrapper {
            background-color: var(--bg-dark) !important;
        }

        /* 2. SIDEBAR GRADIENT (BIRU -> EMERALD) */
        .bg-gradient-primary {
            background-color: #2563eb;
            background-image: linear-gradient(180deg, #2563eb 0%, #10b981 100%) !important;
            background-size: cover;
            border-right: 1px solid var(--border-glass);
        }

        /* 3. TOPBAR (NAVBAR ATAS) */
        .topbar {
            background-color: rgba(15, 23, 42, 0.8) !important; /* Semi transparan */
            backdrop-filter: blur(12px); /* Efek Blur */
            border-bottom: 1px solid var(--border-glass);
        }
        
        /* 4. CARD GLASSMORPHISM (KOTAK-KOTAK) */
        .card {
            background: var(--bg-card) !important;
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-glass) !important;
            border-radius: 1rem !important; /* Sudut tumpul */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        .card-header {
            background-color: transparent !important;
            border-bottom: 1px solid var(--border-glass) !important;
        }

        /* 5. TEKS & JUDUL (FORCE WHITE) */
        h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6, .text-gray-800 {
            color: var(--text-main) !important;
            font-weight: 700 !important;
        }
        .text-gray-600, .text-gray-400 {
            color: var(--text-muted) !important;
        }

        /* 6. TABEL & INPUT FORM */
        .table {
            color: var(--text-muted) !important;
        }
        .table-bordered td, .table-bordered th {
            border-color: var(--border-glass) !important;
        }
        .table thead th {
            color: #38bdf8; /* Sky Blue */
            border-bottom: 2px solid var(--border-glass);
        }
        
        /* Input jadi gelap transparan */
        .form-control, .custom-select {
            background-color: rgba(255, 255, 255, 0.05) !important;
            border: 1px solid var(--border-glass) !important;
            color: white !important;
            border-radius: 0.5rem;
        }
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.1) !important;
            border-color: #3b82f6 !important; /* Blue 500 */
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25) !important;
        }

        /* 7. FOOTER */
        footer.sticky-footer {
            background-color: var(--bg-dark) !important;
            color: var(--text-muted) !important;
            border-top: 1px solid var(--border-glass);
        }

        /* 8. MODAL (Logout dkk) */
        .modal-content {
            background-color: #1e293b; /* Slate 800 */
            color: white;
            border: 1px solid var(--border-glass);
        }
        .close {
            color: white;
            text-shadow: none;
        }
        .close:hover { color: #cbd5e1; }

        /* Scrollbar Keren */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #0f172a; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #475569; }
    </style>

</head>

<body id="page-top">

    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/admin">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-cubes"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Inventaris</div>
            </a>

            <hr class="sidebar-divider my-0">

            <li class="nav-item active">
                <a class="nav-link" href="/admin">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/admin/barang">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Data Barang</span></a>
            </li>

            <hr class="sidebar-divider">

            <div class="sidebar-heading">
                Transaksi
            </div>

            <li class="nav-item">
                <a class="nav-link" href="/admin/masuk">
                    <i class="fas fa-fw fa-arrow-circle-down"></i>
                    <span>Barang Masuk</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/admin/keluar">
                    <i class="fas fa-fw fa-arrow-circle-up"></i>
                    <span>Barang Keluar</span></a>
            </li>

            <hr class="sidebar-divider">

            <div class="sidebar-heading">
                Laporan
            </div>

            <li class="nav-item">
                <a class="nav-link" href="/admin/laporan">
                    <i class="fas fa-fw fa-file-alt"></i>
                    <span>Laporan</span></a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">

            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <div id="content-wrapper" class="d-flex flex-column">

            <div id="content">

                <nav class="navbar navbar-expand navbar-light topbar mb-4 static-top shadow">

                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline small" style="color: white;">Admin</span>
                                <img class="img-profile rounded-circle"
                                    src="{{ asset('sbadmin/img/undraw_profile.svg') }}">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <div class="container-fluid">

                    @yield('content')

                </div>
                </div>
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Inventaris System {{ date('Y') }}</span>
                    </div>
                </div>
            </footer>
            </div>
        </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yakin mau keluar?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik "Logout" di bawah jika kamu ingin mengakhiri sesi ini.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-primary">Logout</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('sbadmin/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <script src="{{ asset('sbadmin/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <script src="{{ asset('sbadmin/js/sb-admin-2.min.js') }}"></script>

    <script src="{{ asset('sbadmin/vendor/chart.js/Chart.min.js') }}"></script>
    
    <x-notify::notify />
    @notifyJs

</body>
</html>